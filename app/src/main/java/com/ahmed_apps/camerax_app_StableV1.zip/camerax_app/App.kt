package com.ahmed_apps.camerax_app

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

/**
 * @author Ahmed Guedmioui
 */
@HiltAndroidApp
class App: Application()